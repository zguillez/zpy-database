from zpy_database import database


database = database.Database()
